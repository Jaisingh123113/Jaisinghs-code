package org.example;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class StudentManagement {
    static ArrayList<Student> studentArrayList = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void addStudent() {
        System.out.print("Enter Roll No: ");
        int rollNo = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Marks: ");
        double marks = scanner.nextDouble();

        studentArrayList.add(new Student(rollNo, name, marks));
        System.out.println("Student added successfully!\n");
    }

    //Display all students//
    public static void displayStudents() {
        if (studentArrayList.isEmpty()) {

            System.out.println("No student available.\n");
            return;
        }
        System.out.println("Student List:");
        for (Student s : studentArrayList) {
            System.out.println(s);
        }
        System.out.println();
    }


    //Remove Student by roll number//

    public static void removeStudent() {
        System.out.println("Enter Roll no to Remove: ");
        int rollNo = scanner.nextInt();
        Iterator<Student> iterator = studentArrayList.iterator();

        while (iterator.hasNext()) {
            Student s = iterator.next();
            if (s.rollNo == rollNo) {
                iterator.remove();
                System.out.println("Student Removed Successfully ! \n");
                return;
            }
        }
        System.out.println("Student not found. \n");

    }
    //update student detail//

    public static void updateStudent() {
        System.out.println("Enter roll no to update: ");
        int rollNo = scanner.nextInt();
        scanner.nextLine();


        for (Student s : studentArrayList) {
            if (s.rollNo == rollNo) {
                System.out.println("Enter New Name: ");
                s.name = String.valueOf(scanner.nextDouble());

                System.out.println("Student Update Succesfully !\n");
                return;
            }
        }
        System.out.println("Student not found.\n");

    }

    public static void main(String[] args) {
        while (true){
            System.out.println("1,Add student");
            System.out.println("2,Display student");
            System.out.println("3,Remove student");
            System.out.println("4,Update student");
            System.out.println("5,Exit");
            System.out.println("Enter your Choice: ");

            int choice =scanner.nextInt();

            switch (choice){
                case 1 ->addStudent();
                case 2 ->displayStudents();
                case 3 ->removeStudent();
                case 4 ->updateStudent();
                case 5 ->{
                    System.out.println("Exiting....");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid choice ! Please enter again.");

            }
        }
    }
}

